/* parallel not implemented yet */

int cma_parallel_not_implemented = 1;
